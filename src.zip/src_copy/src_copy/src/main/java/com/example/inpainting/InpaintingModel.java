package com.example.inpainting;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Build;

import java.io.IOException;
import java.io.InputStream;
import java.nio.FloatBuffer;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import ai.onnxruntime.OnnxTensor;
import ai.onnxruntime.OnnxValue;
import ai.onnxruntime.OrtEnvironment;
import ai.onnxruntime.OrtException;
import ai.onnxruntime.OrtSession;
import ai.onnxruntime.OrtSession.SessionOptions;





public class InpaintingModel {
    private int imageHeight = 256;
    private int imageWidth = 256;

    private OrtEnvironment environment;
    private SessionOptions options;

    private Bitmap gt_img;

    private Bitmap scaled_mask;

    private int random_seed = 2023;

    private OrtSession mappingNetSession;
    private OrtSession encoderSession;
    private OrtSession generatorSession;


    private Random rand_gen = new Random(random_seed);

    public InpaintingModel(Resources resources) throws OrtException, IOException {
        this.mappingNetSession = make_session(resources.openRawResource(R.raw.mapping));
        this.encoderSession = make_session(resources.openRawResource(R.raw.encoder));
        this.generatorSession = make_session(resources.openRawResource(R.raw.generator));
    }


    private OrtSession make_session(InputStream inputStream) throws OrtException, IOException {
        //load the model
        byte[] modelBytes = new byte[inputStream.available()];
        inputStream.read(modelBytes);

        // 创建一个ONNX Runtime环境
        environment = OrtEnvironment.getEnvironment();

        // 配置ONNX Session的参数
        options = new SessionOptions();
        options.setIntraOpNumThreads(8);    //Sets the size of the CPU thread pool used for executing a single graph, if executing on a CPU.

        // 创建一个ONNX Session

        return environment.createSession(modelBytes, options);
    }


    public OnnxTensor preprocess(Bitmap img, Bitmap mask, int channels) throws OrtException {
        this.gt_img = Bitmap.createScaledBitmap(img, imageWidth, imageHeight, true);
        this.scaled_mask = Bitmap.createScaledBitmap(mask, imageWidth, imageHeight, true);
        FloatBuffer imgData = FloatBuffer.allocate(
                        channels
                        * imageWidth
                        * imageHeight
        );
        imgData.rewind();
        int stride = imageHeight * imageWidth;
        int[] bmpData = new int[stride];
        int[] maskData = new int[stride];
        this.gt_img.getPixels(bmpData, 0, imageWidth, 0, 0, imageWidth, imageHeight);
        this.scaled_mask.getPixels(maskData, 0, imageWidth, 0, 0, imageWidth,imageHeight);

        // row first
        for (int i = 0; i < imageHeight; i++) {
            for (int j = 0; j < imageWidth; j++) {
                int idx = imageWidth * i + j;
                int pixelValue = bmpData[idx];
                float maskValue = (pixelValue  == maskData[idx])  ? 1.0f : 0.0f ; //0 for holes in mask
                imgData.put(idx, (((pixelValue >> 16 & 0xFF) / 127.5f) - 1.0f) * maskValue);   //R
                imgData.put(idx + stride, (((pixelValue >> 8 & 0xFF) / 127.5f) - 1.0f) * maskValue); //G
                imgData.put(idx + stride * 2, (((pixelValue & 0xFF) / 127.5f) - 1.0f) * maskValue); //B
                imgData.put(idx + stride * 3, maskValue); //Mask
            }
        }

        imgData.rewind();

        long[] target_shape = new long[]{1, channels, imageHeight, imageWidth};
        // 创建输入张量
        OnnxTensor inputTensor = OnnxTensor.createTensor(environment, imgData, target_shape);

        return inputTensor;
    }

    public Bitmap[] postprocess(float[] out_array) {
        Bitmap comp_out_img = Bitmap.createBitmap(imageWidth, imageHeight, Bitmap.Config.ARGB_8888);
        Bitmap in_mask = Bitmap.createBitmap(imageWidth, imageHeight, Bitmap.Config.ARGB_8888);
        int stride = imageHeight * imageWidth;
        int[] imgData = new int[stride];
        int[] maskData = new int[stride];
        this.gt_img.getPixels(imgData, 0, imageWidth, 0, 0, imageWidth, imageHeight);
        this.scaled_mask.getPixels(maskData, 0, imageWidth, 0, 0, imageWidth,imageHeight);
        for (int i = 0; i < imageHeight; i++) {
            for (int j = 0; j < imageWidth; j++) {
                int idx = imageWidth * i + j;
                int gt_pixelValue = imgData[idx];
                float maskValue = (gt_pixelValue  == maskData[idx])  ? 1.0f : 0.0f ; //0 for holes in mask

                float gt_R = (gt_pixelValue >> 16 & 0xFF) / 255f * maskValue;
                float gt_G = (gt_pixelValue >> 8 & 0xFF) / 255f  * maskValue;
                float gt_B = (gt_pixelValue & 0xFF) / 255f  * maskValue;

                float fake_R = (out_array[idx] + 1.0f) * 0.5f * (1.0f - maskValue);
                float fake_G = (out_array[idx + stride] + 1.0f) * 0.5f * (1.0f - maskValue);
                float fake_B = (out_array[idx + stride * 2] + 1.0f) * 0.5f * (1.0f - maskValue);

                float comp_R = (gt_R + fake_R);
                float comp_G = (gt_G + fake_G);
                float comp_B = (gt_B + fake_B);

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    comp_out_img.setPixel(j,i,Color.argb(1.0f,comp_R,comp_G,comp_B));
                    in_mask.setPixel(j,i,Color.argb(1.0f,maskValue,maskValue,maskValue));
                }

            }
        }

        Bitmap[] out = new Bitmap[] {comp_out_img, in_mask};

        return out;
    }

    private OnnxTensor gen_rand_noise(int rows, int cols) throws OrtException{
        float[] arr = new float[rows * cols];
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                arr[i * cols + j] = ((float) this.rand_gen.nextGaussian());
            }
        }

        FloatBuffer floatBuffer = FloatBuffer.wrap(arr);

        long[] target_shape = new long[]{rows,cols};

        floatBuffer.rewind();

        // 创建输入张量
        OnnxTensor noiseTensor = OnnxTensor.createTensor(environment, floatBuffer, target_shape);

        return noiseTensor;
    }


    public Bitmap[] Inference(Bitmap inputImage, Bitmap mask) throws OrtException{
        OnnxTensor input = preprocess(inputImage,mask,4);

        OnnxTensor z = gen_rand_noise(1,512);
        OnnxTensor ws =  (OnnxTensor) mappingNetSession.run(Collections.singletonMap("noise", z)).get(0);
        Map<String,OnnxTensor> en_in_dict = new HashMap<>();
        en_in_dict.put("input",input);
        en_in_dict.put("styles",ws);
        Iterator<Map.Entry<String, OnnxValue>> en_out =  encoderSession.run(en_in_dict).iterator();

        Set<String> gen_input_names = generatorSession.getInputNames();

        Map<String,OnnxTensor> gen_in_dict = new HashMap<>();

        for (String name: gen_input_names){
            gen_in_dict.put(name,(OnnxTensor) en_out.next().getValue());
        }

        OnnxTensor outputTensor = (OnnxTensor) generatorSession.run(gen_in_dict).get(0);

        return postprocess(outputTensor.getFloatBuffer().array());
    }


}
